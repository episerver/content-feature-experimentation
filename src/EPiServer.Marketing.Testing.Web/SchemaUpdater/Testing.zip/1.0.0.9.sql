--beginvalidatingquery

		 select 1, 'Upgrading database'

--endvalidatingquery

GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tblABTest')
BEGIN
	IF NOT EXISTS (SELECT 1
			FROM syscolumns
			WHERE ID=OBJECT_ID('[dbo].[tblABTest]') AND NAME='FS_FlagKey')
	BEGIN
		--select -1, 'ADD Columns HERE'
		PRINT N'Altering Table [dbo].[tblABTest]...';
		ALTER TABLE [dbo].[tblABTest] ADD [FS_FlagKey] nvarchar(100) NULL;
	END
	ELSE
		select -1, 'Column Already Exists'


	IF NOT EXISTS (SELECT 1
			FROM syscolumns
			WHERE ID=OBJECT_ID('[dbo].[tblABTest]') AND NAME='FS_ExperimentKey')
	BEGIN
		PRINT N'Altering Table [dbo].[tblABTest]...';
		ALTER TABLE [dbo].[tblABTest] ADD [FS_ExperimentKey] nvarchar(100) NULL;
	END
	ELSE
		select -1, 'Column Already Exists'
		
END
Else
Print 'table [dbo].[tblABTest] does not exist'


